export interface RPPFormData {
  namaInstansi: string;
  mataPelajaran: string;
  kelas: string;
  jenjang: string;
  fase: string;
  semester: string;
  materi: string;
  subMateri: string;
  tujuanPembelajaran: string;
  capaianPembelajaran: string;
  namaPenyusun: string;
  dokumenReferensi: File | null;
}

export interface GeneratedRPP {
  identitas: {
    namaInstansi: string;
    mataPelajaran: string;
    kelasFaseSemester: string;
    alokasiWaktu: string;
    materi: string;
    subMateri: string;
    namaPenyusun: string;
  };
  identifikasi: {
    murid: {
      pengetahuanAwal: string;
      minat: string;
      latarBelakang: string;
      kebutuhanBelajar: string;
    };
    materi: {
      pengetahuanKonseptual: string;
      pengetahuanProsedural: string;
      pengetahuanNilai: string;
      relevansi: string;
      tingkatKesulitan: string;
      strukturMateri: string;
    };
    dimensiProfilLulusan: {
      dimensi: string[];
      penjelasan: string;
    };
  };
  desainPembelajaran: {
    capaianPembelajaran: string;
    lintasDisiplin: string;
    tujuanPembelajaran: string;
    praktikPedagogis: {
      model: string;
      sintak: string[];
    };
    kemitraan: string;
    lingkungan: {
      budaya: string;
      ruangFisik: string;
      ruangVirtual: string;
    };
  };
  pengalamanBelajar: {
    awal: string[];
    inti: {
      memahami: string[];
      mengaplikasi: string[];
      merefleksi: string[];
    };
    penutup: string[];
  };
  asesmen: {
    awal: string;
    proses: string;
    akhir: string;
  };
}

export const MATA_PELAJARAN_OPTIONS = [
  { value: "matematika", label: "Matematika" },
  { value: "ipa", label: "IPA" },
  { value: "ips", label: "IPS" },
  { value: "pai", label: "PAI" },
  { value: "pjok", label: "PJOK" },
  { value: "sb", label: "SB (Seni Budaya)" },
  { value: "bahasa_indonesia", label: "Bahasa Indonesia" },
  { value: "bahasa_inggris", label: "Bahasa Inggris" },
  { value: "informatika", label: "Informatika" },
  { value: "pkn", label: "PKn" },
  { value: "geografi", label: "Geografi" },
  { value: "sejarah", label: "Sejarah" },
  { value: "ekonomi", label: "Ekonomi" },
  { value: "sosiologi", label: "Sosiologi" },
  { value: "kimia", label: "Kimia" },
  { value: "biologi", label: "Biologi" },
  { value: "fisika", label: "Fisika" },
];

export const KELAS_OPTIONS = [
  { value: "1", label: "1" },
  { value: "2", label: "2" },
  { value: "3", label: "3" },
  { value: "4", label: "4" },
  { value: "5", label: "5" },
  { value: "6", label: "6" },
  { value: "7", label: "7" },
  { value: "8", label: "8" },
  { value: "9", label: "9" },
  { value: "10", label: "10" },
  { value: "11", label: "11" },
  { value: "12", label: "12" },
];

export const JENJANG_OPTIONS = [
  { value: "sd_mi", label: "SD/MI", alokasiWaktu: "2 x 30 menit" },
  { value: "smp_mts", label: "SMP/MTs", alokasiWaktu: "2 x 40 menit" },
  { value: "sma", label: "SMA", alokasiWaktu: "2 x 45 menit" },
];

export const FASE_OPTIONS = [
  { value: "A", label: "A" },
  { value: "B", label: "B" },
  { value: "C", label: "C" },
  { value: "D", label: "D" },
  { value: "E", label: "E" },
  { value: "F", label: "F" },
];

export const SEMESTER_OPTIONS = [
  { value: "1", label: "1" },
  { value: "2", label: "2" },
];

export const DIMENSI_PROFIL_LULUSAN = [
  { value: "keimanan", label: "Keimanan" },
  { value: "kewargaan", label: "Kewargaan" },
  { value: "penalaran_kritis", label: "Penalaran Kritis" },
  { value: "kreativitas", label: "Kreativitas" },
  { value: "kolaborasi", label: "Kolaborasi" },
  { value: "kemandirian", label: "Kemandirian" },
  { value: "kesehatan", label: "Kesehatan" },
  { value: "komunikasi", label: "Komunikasi" },
];
