import { useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Copy, Download, FileText, CheckCircle } from 'lucide-react';
import type { GeneratedRPP } from '@/types/rpp';
import { useToast } from '@/hooks/use-toast';

interface RPPResultProps {
  rpp: GeneratedRPP | null;
}

export function RPPResult({ rpp }: RPPResultProps) {
  const { toast } = useToast();
  const contentRef = useRef<HTMLDivElement>(null);

  const handleCopy = useCallback(async () => {
    if (!contentRef.current) return;
    
    try {
      const text = contentRef.current.innerText;
      await navigator.clipboard.writeText(text);
      toast({
        title: 'Berhasil Disalin!',
        description: 'Konten RPP telah disalin ke clipboard.',
        variant: 'default',
      });
    } catch (err) {
      toast({
        title: 'Gagal Menyalin',
        description: 'Terjadi kesalahan saat menyalin konten.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  const handleDownload = useCallback(() => {
    if (!rpp) return;

    const content = generateRPPDocument(rpp);
    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `RPP_${rpp.identitas.mataPelajaran.replace(/\s+/g, '_')}_${rpp.identitas.kelasFaseSemester.replace(/\//g, '_')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: 'Berhasil Diunduh!',
      description: 'File RPP telah berhasil diunduh.',
      variant: 'default',
    });
  }, [rpp, toast]);

  if (!rpp) {
    return (
      <Card className="w-full h-full min-h-[400px] flex items-center justify-center shadow-lg border-t-4 border-t-slate-300">
        <div className="text-center p-8">
          <FileText className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-600 mb-2">
            Belum Ada Hasil Generate
          </h3>
          <p className="text-slate-500 max-w-md">
            Isi form input dengan lengkap dan klik tombol "Generate RPP" untuk menghasilkan dokumen RPP Pembelajaran Mendalam.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="w-full shadow-lg border-t-4 border-t-green-600">
      <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 flex flex-row items-center justify-between">
        <CardTitle className="text-xl text-green-900 flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          Hasil Generate RPP
        </CardTitle>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleCopy}
            className="flex items-center gap-2"
          >
            <Copy className="w-4 h-4" />
            Salin
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={handleDownload}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
          >
            <Download className="w-4 h-4" />
            Unduh
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[800px] w-full">
          <div ref={contentRef} className="p-6 space-y-8">
            {/* A. IDENTITAS */}
            <section>
              <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-200 pb-2 mb-4">
                A. IDENTITAS
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-semibold text-slate-700">Nama Instansi:</span>
                  <p className="text-slate-600 mt-1">{rpp.identitas.namaInstansi}</p>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Mata Pelajaran:</span>
                  <p className="text-slate-600 mt-1">{rpp.identitas.mataPelajaran}</p>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Kelas/Fase/Semester:</span>
                  <p className="text-slate-600 mt-1">{rpp.identitas.kelasFaseSemester}</p>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Alokasi Waktu:</span>
                  <p className="text-slate-600 mt-1">{rpp.identitas.alokasiWaktu}</p>
                </div>
                <div className="md:col-span-2">
                  <span className="font-semibold text-slate-700">Materi:</span>
                  <p className="text-slate-600 mt-1">{rpp.identitas.materi}</p>
                </div>
                <div className="md:col-span-2">
                  <span className="font-semibold text-slate-700">Sub Materi:</span>
                  <p className="text-slate-600 mt-1">{rpp.identitas.subMateri}</p>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Nama Penyusun:</span>
                  <p className="text-slate-600 mt-1">{rpp.identitas.namaPenyusun}</p>
                </div>
              </div>
            </section>

            {/* B. IDENTIFIKASI */}
            <section>
              <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-200 pb-2 mb-4">
                B. IDENTIFIKASI
              </h2>
              
              {/* 1. Identifikasi Murid */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-3">
                  1. Identifikasi Murid
                </h3>
                <div className="space-y-3 pl-4">
                  <div>
                    <h4 className="font-medium text-slate-700">Pengetahuan Awal:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.murid.pengetahuanAwal}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Minat:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.murid.minat}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Latar Belakang:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.murid.latarBelakang}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Kebutuhan Belajar:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.murid.kebutuhanBelajar}
                    </p>
                  </div>
                </div>
              </div>

              {/* 2. Identifikasi Materi Pelajaran */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-3">
                  2. Identifikasi Materi Pelajaran
                </h3>
                <div className="space-y-3 pl-4">
                  <div>
                    <h4 className="font-medium text-slate-700">Pengetahuan Konseptual:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.materi.pengetahuanKonseptual}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Pengetahuan Prosedural:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.materi.pengetahuanProsedural}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Pengetahuan Nilai dan Karakter:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.materi.pengetahuanNilai}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Relevansi dengan Kehidupan Murid:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.materi.relevansi}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Tingkat Kesulitan:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.materi.tingkatKesulitan}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-700">Struktur Materi:</h4>
                    <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                      {rpp.identifikasi.materi.strukturMateri}
                    </p>
                  </div>
                </div>
              </div>

              {/* 3. Dimensi Profil Lulusan */}
              <div>
                <h3 className="text-lg font-semibold text-slate-800 mb-3">
                  3. Dimensi Profil Lulusan
                </h3>
                <div className="pl-4">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {rpp.identifikasi.dimensiProfilLulusan.dimensi.map((dim, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
                      >
                        {dim === 'penalaran_kritis' ? 'Penalaran Kritis' :
                         dim === 'kreativitas' ? 'Kreativitas' :
                         dim === 'kolaborasi' ? 'Kolaborasi' :
                         dim === 'kemandirian' ? 'Kemandirian' :
                         dim === 'komunikasi' ? 'Komunikasi' :
                         dim === 'keimanan' ? 'Keimanan' :
                         dim === 'kewargaan' ? 'Kewargaan' :
                         dim === 'kesehatan' ? 'Kesehatan' : dim}
                      </span>
                    ))}
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {rpp.identifikasi.dimensiProfilLulusan.penjelasan}
                  </p>
                </div>
              </div>
            </section>

            {/* C. DESAIN PEMBELAJARAN */}
            <section>
              <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-200 pb-2 mb-4">
                C. DESAIN PEMBELAJARAN
              </h2>
              
              <div className="space-y-4 pl-4">
                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">1. Capaian Pembelajaran</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {rpp.desainPembelajaran.capaianPembelajaran}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">2. Lintas Disiplin Ilmu</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {rpp.desainPembelajaran.lintasDisiplin}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">3. Tujuan Pembelajaran</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {rpp.desainPembelajaran.tujuanPembelajaran}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">4. Praktik Pedagogis</h3>
                  <p className="text-slate-700 font-medium text-sm mb-2">
                    Model: {rpp.desainPembelajaran.praktikPedagogis.model}
                  </p>
                  <div className="space-y-1">
                    {rpp.desainPembelajaran.praktikPedagogis.sintak.map((step, idx) => (
                      <p key={idx} className="text-slate-600 text-sm leading-relaxed">
                        {step}
                      </p>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">5. Kemitraan Pembelajaran</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {rpp.desainPembelajaran.kemitraan}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">6. Lingkungan Pembelajaran</h3>
                  <div className="space-y-2">
                    <div>
                      <span className="font-medium text-slate-700 text-sm">Budaya Belajar:</span>
                      <p className="text-slate-600 text-sm mt-1">{rpp.desainPembelajaran.lingkungan.budaya}</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-700 text-sm">Ruang Fisik:</span>
                      <p className="text-slate-600 text-sm mt-1">{rpp.desainPembelajaran.lingkungan.ruangFisik}</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-700 text-sm">Ruang Virtual:</span>
                      <p className="text-slate-600 text-sm mt-1">{rpp.desainPembelajaran.lingkungan.ruangVirtual}</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* D. PENGALAMAN BELAJAR */}
            <section>
              <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-200 pb-2 mb-4">
                D. PENGALAMAN BELAJAR
              </h2>
              
              <div className="space-y-4 pl-4">
                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">1. AWAL (Prinsip: Berkesadaran & Bermakna)</h3>
                  <ul className="list-disc list-inside space-y-1">
                    {rpp.pengalamanBelajar.awal.map((item, idx) => (
                      <li key={idx} className="text-slate-600 text-sm leading-relaxed">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">2. INTI</h3>
                  
                  <div className="space-y-3 pl-4">
                    <div>
                      <h4 className="font-medium text-slate-700 mb-2">A. Memahami (Prinsip: Berkesadaran, Bermakna)</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {rpp.pengalamanBelajar.inti.memahami.map((item, idx) => (
                          <li key={idx} className="text-slate-600 text-sm leading-relaxed">
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-medium text-slate-700 mb-2">B. Mengaplikasi (Prinsip: Bermakna, Menggembirakan)</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {rpp.pengalamanBelajar.inti.mengaplikasi.map((item, idx) => (
                          <li key={idx} className="text-slate-600 text-sm leading-relaxed">
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-medium text-slate-700 mb-2">C. Merefleksi (Prinsip: Berkesadaran, Bermakna)</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {rpp.pengalamanBelajar.inti.merefleksi.map((item, idx) => (
                          <li key={idx} className="text-slate-600 text-sm leading-relaxed">
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">3. PENUTUP (Prinsip: Berkesadaran)</h3>
                  <ul className="list-disc list-inside space-y-1">
                    {rpp.pengalamanBelajar.penutup.map((item, idx) => (
                      <li key={idx} className="text-slate-600 text-sm leading-relaxed">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>

            {/* E. ASESMEN PEMBELAJARAN */}
            <section>
              <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-200 pb-2 mb-4">
                E. ASESMEN PEMBELAJARAN
              </h2>
              
              <div className="space-y-4 pl-4">
                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">1. Penilaian Awal</h3>
                  <p className="text-slate-600 text-sm leading-relaxed whitespace-pre-line">
                    {rpp.asesmen.awal}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">2. Penilaian Proses</h3>
                  <p className="text-slate-600 text-sm leading-relaxed whitespace-pre-line">
                    {rpp.asesmen.proses}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-800 mb-2">3. Penilaian Akhir</h3>
                  <p className="text-slate-600 text-sm leading-relaxed whitespace-pre-line">
                    {rpp.asesmen.akhir}
                  </p>
                </div>
              </div>
            </section>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function generateRPPDocument(rpp: GeneratedRPP): string {
  return `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RPP ${rpp.identitas.mataPelajaran} - Kelas ${rpp.identitas.kelasFaseSemester}</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; max-width: 900px; margin: 0 auto; padding: 20px; }
        h1 { color: #1e3a8a; border-bottom: 2px solid #bfdbfe; padding-bottom: 10px; }
        h2 { color: #1e3a8a; border-bottom: 2px solid #bfdbfe; padding-bottom: 8px; margin-top: 30px; }
        h3 { color: #334155; margin-top: 20px; }
        h4 { color: #475569; }
        .section { margin-bottom: 20px; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .full-width { grid-column: 1 / -1; }
        .label { font-weight: bold; color: #374151; }
        .content { color: #4b5563; }
        ul { margin: 10px 0; padding-left: 20px; }
        li { margin-bottom: 5px; }
        .badge { display: inline-block; background: #dbeafe; color: #1e40af; padding: 4px 12px; border-radius: 20px; margin: 2px; font-size: 14px; }
    </style>
</head>
<body>
    <h1>RENCANA PELAKSANAAN PEMBELAJARAN (RPP)</h1>
    <h2>Pembelajaran Mendalam</h2>
    
    <div class="section">
        <h2>A. IDENTITAS</h2>
        <div class="info-grid">
            <div><span class="label">Nama Instansi:</span> <span class="content">${rpp.identitas.namaInstansi}</span></div>
            <div><span class="label">Mata Pelajaran:</span> <span class="content">${rpp.identitas.mataPelajaran}</span></div>
            <div><span class="label">Kelas/Fase/Semester:</span> <span class="content">${rpp.identitas.kelasFaseSemester}</span></div>
            <div><span class="label">Alokasi Waktu:</span> <span class="content">${rpp.identitas.alokasiWaktu}</span></div>
            <div class="full-width"><span class="label">Materi:</span> <span class="content">${rpp.identitas.materi}</span></div>
            <div class="full-width"><span class="label">Sub Materi:</span> <span class="content">${rpp.identitas.subMateri}</span></div>
            <div><span class="label">Nama Penyusun:</span> <span class="content">${rpp.identitas.namaPenyusun}</span></div>
        </div>
    </div>

    <div class="section">
        <h2>B. IDENTIFIKASI</h2>
        
        <h3>1. Identifikasi Murid</h3>
        <p><strong>Pengetahuan Awal:</strong> ${rpp.identifikasi.murid.pengetahuanAwal}</p>
        <p><strong>Minat:</strong> ${rpp.identifikasi.murid.minat}</p>
        <p><strong>Latar Belakang:</strong> ${rpp.identifikasi.murid.latarBelakang}</p>
        <p><strong>Kebutuhan Belajar:</strong> ${rpp.identifikasi.murid.kebutuhanBelajar}</p>
        
        <h3>2. Identifikasi Materi Pelajaran</h3>
        <p><strong>Pengetahuan Konseptual:</strong> ${rpp.identifikasi.materi.pengetahuanKonseptual}</p>
        <p><strong>Pengetahuan Prosedural:</strong> ${rpp.identifikasi.materi.pengetahuanProsedural}</p>
        <p><strong>Pengetahuan Nilai dan Karakter:</strong> ${rpp.identifikasi.materi.pengetahuanNilai}</p>
        <p><strong>Relevansi:</strong> ${rpp.identifikasi.materi.relevansi}</p>
        <p><strong>Tingkat Kesulitan:</strong> ${rpp.identifikasi.materi.tingkatKesulitan}</p>
        <p><strong>Struktur Materi:</strong> ${rpp.identifikasi.materi.strukturMateri}</p>
        
        <h3>3. Dimensi Profil Lulusan</h3>
        <div>
            ${rpp.identifikasi.dimensiProfilLulusan.dimensi.map(d => `<span class="badge">${d}</span>`).join('')}
        </div>
        <p>${rpp.identifikasi.dimensiProfilLulusan.penjelasan}</p>
    </div>

    <div class="section">
        <h2>C. DESAIN PEMBELAJARAN</h2>
        
        <h3>1. Capaian Pembelajaran</h3>
        <p>${rpp.desainPembelajaran.capaianPembelajaran}</p>
        
        <h3>2. Lintas Disiplin Ilmu</h3>
        <p>${rpp.desainPembelajaran.lintasDisiplin}</p>
        
        <h3>3. Tujuan Pembelajaran</h3>
        <p>${rpp.desainPembelajaran.tujuanPembelajaran}</p>
        
        <h3>4. Praktik Pedagogis</h3>
        <p><strong>Model:</strong> ${rpp.desainPembelajaran.praktikPedagogis.model}</p>
        <ul>
            ${rpp.desainPembelajaran.praktikPedagogis.sintak.map(s => `<li>${s}</li>`).join('')}
        </ul>
        
        <h3>5. Kemitraan Pembelajaran</h3>
        <p>${rpp.desainPembelajaran.kemitraan}</p>
        
        <h3>6. Lingkungan Pembelajaran</h3>
        <p><strong>Budaya Belajar:</strong> ${rpp.desainPembelajaran.lingkungan.budaya}</p>
        <p><strong>Ruang Fisik:</strong> ${rpp.desainPembelajaran.lingkungan.ruangFisik}</p>
        <p><strong>Ruang Virtual:</strong> ${rpp.desainPembelajaran.lingkungan.ruangVirtual}</p>
    </div>

    <div class="section">
        <h2>D. PENGALAMAN BELAJAR</h2>
        
        <h3>1. AWAL (Prinsip: Berkesadaran & Bermakna)</h3>
        <ul>
            ${rpp.pengalamanBelajar.awal.map(item => `<li>${item}</li>`).join('')}
        </ul>
        
        <h3>2. INTI</h3>
        
        <h4>A. Memahami (Prinsip: Berkesadaran, Bermakna)</h4>
        <ul>
            ${rpp.pengalamanBelajar.inti.memahami.map(item => `<li>${item}</li>`).join('')}
        </ul>
        
        <h4>B. Mengaplikasi (Prinsip: Bermakna, Menggembirakan)</h4>
        <ul>
            ${rpp.pengalamanBelajar.inti.mengaplikasi.map(item => `<li>${item}</li>`).join('')}
        </ul>
        
        <h4>C. Merefleksi (Prinsip: Berkesadaran, Bermakna)</h4>
        <ul>
            ${rpp.pengalamanBelajar.inti.merefleksi.map(item => `<li>${item}</li>`).join('')}
        </ul>
        
        <h3>3. PENUTUP (Prinsip: Berkesadaran)</h3>
        <ul>
            ${rpp.pengalamanBelajar.penutup.map(item => `<li>${item}</li>`).join('')}
        </ul>
    </div>

    <div class="section">
        <h2>E. ASESMEN PEMBELAJARAN</h2>
        
        <h3>1. Penilaian Awal</h3>
        <p>${rpp.asesmen.awal.replace(/\n/g, '<br>')}</p>
        
        <h3>2. Penilaian Proses</h3>
        <p>${rpp.asesmen.proses.replace(/\n/g, '<br>')}</p>
        
        <h3>3. Penilaian Akhir</h3>
        <p>${rpp.asesmen.akhir.replace(/\n/g, '<br>')}</p>
    </div>
</body>
</html>`;
}
