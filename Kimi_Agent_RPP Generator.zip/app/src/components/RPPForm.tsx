import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, RotateCcw, FileText } from 'lucide-react';
import type { RPPFormData } from '@/types/rpp';
import {
  MATA_PELAJARAN_OPTIONS,
  KELAS_OPTIONS,
  JENJANG_OPTIONS,
  FASE_OPTIONS,
  SEMESTER_OPTIONS,
} from '@/types/rpp';

interface RPPFormProps {
  onSubmit: (data: RPPFormData) => void;
  onReset: () => void;
  isLoading: boolean;
}

const initialFormData: RPPFormData = {
  namaInstansi: '',
  mataPelajaran: '',
  kelas: '',
  jenjang: '',
  fase: '',
  semester: '',
  materi: '',
  subMateri: '',
  tujuanPembelajaran: '',
  capaianPembelajaran: '',
  namaPenyusun: '',
  dokumenReferensi: null,
};

export function RPPForm({ onSubmit, onReset, isLoading }: RPPFormProps) {
  const [formData, setFormData] = useState<RPPFormData>(initialFormData);
  const [alokasiWaktu, setAlokasiWaktu] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');

  const handleInputChange = useCallback((field: keyof RPPFormData, value: string | File | null) => {
    setFormData((prev) => ({ ...prev, [field]: value }));

    if (field === 'jenjang') {
      const jenjangOption = JENJANG_OPTIONS.find((j) => j.value === value);
      setAlokasiWaktu(jenjangOption?.alokasiWaktu || '');
    }
  }, []);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    handleInputChange('dokumenReferensi', file);
    setFileName(file?.name || '');
  }, [handleInputChange]);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  }, [formData, onSubmit]);

  const handleReset = useCallback(() => {
    setFormData(initialFormData);
    setAlokasiWaktu('');
    setFileName('');
    onReset();
  }, [onReset]);

  return (
    <Card className="w-full shadow-lg border-t-4 border-t-blue-600">
      <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardTitle className="text-xl text-blue-900 flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Form Input RPP Pembelajaran Mendalam
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Header Form Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Nama Instansi */}
            <div className="space-y-2">
              <Label htmlFor="namaInstansi" className="text-slate-700 font-medium">
                Nama Instansi <span className="text-red-500">*</span>
              </Label>
              <Input
                id="namaInstansi"
                placeholder="Contoh: SD Negeri 1 Jakarta"
                value={formData.namaInstansi}
                onChange={(e) => handleInputChange('namaInstansi', e.target.value)}
                required
                className="focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Mata Pelajaran */}
            <div className="space-y-2">
              <Label htmlFor="mataPelajaran" className="text-slate-700 font-medium">
                Mata Pelajaran <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.mataPelajaran}
                onValueChange={(value) => handleInputChange('mataPelajaran', value)}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="Pilih Mata Pelajaran" />
                </SelectTrigger>
                <SelectContent>
                  {MATA_PELAJARAN_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Kelas */}
            <div className="space-y-2">
              <Label htmlFor="kelas" className="text-slate-700 font-medium">
                Kelas <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.kelas}
                onValueChange={(value) => handleInputChange('kelas', value)}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="Pilih Kelas" />
                </SelectTrigger>
                <SelectContent>
                  {KELAS_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Jenjang */}
            <div className="space-y-2">
              <Label htmlFor="jenjang" className="text-slate-700 font-medium">
                Jenjang <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.jenjang}
                onValueChange={(value) => handleInputChange('jenjang', value)}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="Pilih Jenjang" />
                </SelectTrigger>
                <SelectContent>
                  {JENJANG_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Alokasi Waktu (Otomatis) */}
            <div className="space-y-2">
              <Label htmlFor="alokasiWaktu" className="text-slate-700 font-medium">
                Alokasi Waktu <span className="text-xs text-slate-500">(Otomatis)</span>
              </Label>
              <Input
                id="alokasiWaktu"
                value={alokasiWaktu}
                readOnly
                disabled
                className="bg-slate-100 text-slate-600"
                placeholder="Pilih jenjang terlebih dahulu"
              />
            </div>

            {/* Fase */}
            <div className="space-y-2">
              <Label htmlFor="fase" className="text-slate-700 font-medium">
                Fase <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.fase}
                onValueChange={(value) => handleInputChange('fase', value)}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="Pilih Fase" />
                </SelectTrigger>
                <SelectContent>
                  {FASE_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Semester */}
            <div className="space-y-2">
              <Label htmlFor="semester" className="text-slate-700 font-medium">
                Semester <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.semester}
                onValueChange={(value) => handleInputChange('semester', value)}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="Pilih Semester" />
                </SelectTrigger>
                <SelectContent>
                  {SEMESTER_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Nama Penyusun */}
            <div className="space-y-2">
              <Label htmlFor="namaPenyusun" className="text-slate-700 font-medium">
                Nama Penyusun <span className="text-red-500">*</span>
              </Label>
              <Input
                id="namaPenyusun"
                placeholder="Nama lengkap penyusun RPP"
                value={formData.namaPenyusun}
                onChange={(e) => handleInputChange('namaPenyusun', e.target.value)}
                required
                className="focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Textarea Fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Materi */}
            <div className="space-y-2">
              <Label htmlFor="materi" className="text-slate-700 font-medium">
                Materi <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="materi"
                placeholder="Tuliskan materi pelajaran yang akan diajarkan..."
                value={formData.materi}
                onChange={(e) => handleInputChange('materi', e.target.value)}
                required
                className="min-h-[100px] focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Sub Materi */}
            <div className="space-y-2">
              <Label htmlFor="subMateri" className="text-slate-700 font-medium">
                Sub Materi <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="subMateri"
                placeholder="Tuliskan sub materi yang akan dipelajari..."
                value={formData.subMateri}
                onChange={(e) => handleInputChange('subMateri', e.target.value)}
                required
                className="min-h-[100px] focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Tujuan Pembelajaran */}
            <div className="space-y-2">
              <Label htmlFor="tujuanPembelajaran" className="text-slate-700 font-medium">
                Tujuan Pembelajaran <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="tujuanPembelajaran"
                placeholder="Tuliskan tujuan pembelajaran yang ingin dicapai..."
                value={formData.tujuanPembelajaran}
                onChange={(e) => handleInputChange('tujuanPembelajaran', e.target.value)}
                required
                className="min-h-[120px] focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Capaian Pembelajaran */}
            <div className="space-y-2">
              <Label htmlFor="capaianPembelajaran" className="text-slate-700 font-medium">
                Capaian Pembelajaran <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="capaianPembelajaran"
                placeholder="Tuliskan capaian pembelajaran sesuai kurikulum..."
                value={formData.capaianPembelajaran}
                onChange={(e) => handleInputChange('capaianPembelajaran', e.target.value)}
                required
                className="min-h-[120px] focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="dokumenReferensi" className="text-slate-700 font-medium">
              Unggah Dokumen Referensi
              <span className="text-xs text-slate-500 ml-2">(Opsional - untuk referensi materi)</span>
            </Label>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors border border-slate-300">
                <Upload className="w-4 h-4 text-slate-600" />
                <span className="text-sm text-slate-700">Pilih File</span>
                <input
                  id="dokumenReferensi"
                  type="file"
                  accept=".pdf,.doc,.docx,.txt"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
              {fileName && (
                <span className="text-sm text-green-600 flex items-center gap-1">
                  <FileText className="w-4 h-4" />
                  {fileName}
                </span>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-slate-200">
            <Button
              type="submit"
              disabled={isLoading}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 h-auto"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="none"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                  Sedang Generate RPP...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Generate RPP
                </span>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleReset}
              disabled={isLoading}
              className="flex-1 sm:flex-none px-6 py-3 h-auto border-slate-400 text-slate-700 hover:bg-slate-100"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset Form
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
