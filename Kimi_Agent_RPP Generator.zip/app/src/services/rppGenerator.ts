import type { RPPFormData, GeneratedRPP } from '@/types/rpp';

export async function generateRPP(formData: RPPFormData): Promise<GeneratedRPP> {
  // Simulasi delay untuk proses generate
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const jenjangLabel = getJenjangLabel(formData.jenjang);
  const mataPelajaranLabel = getMataPelajaranLabel(formData.mataPelajaran);
  const alokasiWaktu = getAlokasiWaktu(formData.jenjang);

  // Generate konten berdasarkan input
  const generatedRPP: GeneratedRPP = {
    identitas: {
      namaInstansi: formData.namaInstansi,
      mataPelajaran: mataPelajaranLabel,
      kelasFaseSemester: `${formData.kelas}/${formData.fase}/${formData.semester}`,
      alokasiWaktu: alokasiWaktu,
      materi: formData.materi,
      subMateri: formData.subMateri,
      namaPenyusun: formData.namaPenyusun,
    },
    identifikasi: {
      murid: {
        pengetahuanAwal: generatePengetahuanAwal(mataPelajaranLabel, formData.materi, jenjangLabel),
        minat: generateMinat(mataPelajaranLabel, jenjangLabel),
        latarBelakang: generateLatarBelakang(jenjangLabel),
        kebutuhanBelajar: generateKebutuhanBelajar(mataPelajaranLabel, formData.materi),
      },
      materi: {
        pengetahuanKonseptual: generatePengetahuanKonseptual(formData.materi, formData.subMateri),
        pengetahuanProsedural: generatePengetahuanProsedural(formData.materi, mataPelajaranLabel),
        pengetahuanNilai: generatePengetahuanNilai(mataPelajaranLabel, formData.materi),
        relevansi: generateRelevansi(formData.materi, jenjangLabel),
        tingkatKesulitan: generateTingkatKesulitan(formData.materi, jenjangLabel),
        strukturMateri: generateStrukturMateri(formData.materi, formData.subMateri),
      },
      dimensiProfilLulusan: generateDimensiProfilLulusan(mataPelajaranLabel, formData.tujuanPembelajaran),
    },
    desainPembelajaran: {
      capaianPembelajaran: formData.capaianPembelajaran,
      lintasDisiplin: generateLintasDisiplin(mataPelajaranLabel),
      tujuanPembelajaran: formData.tujuanPembelajaran,
      praktikPedagogis: generatePraktikPedagogis(mataPelajaranLabel, formData.materi),
      kemitraan: generateKemitraan(),
      lingkungan: {
        budaya: generateBudayaBelajar(),
        ruangFisik: generateRuangFisik(),
        ruangVirtual: generateRuangVirtual(),
      },
    },
    pengalamanBelajar: {
      awal: generateKegiatanAwal(mataPelajaranLabel, formData.materi),
      inti: {
        memahami: generateKegiatanMemahami(formData.materi, formData.subMateri, mataPelajaranLabel),
        mengaplikasi: generateKegiatanMengaplikasi(formData.materi, mataPelajaranLabel),
        merefleksi: generateKegiatanMerefleksi(),
      },
      penutup: generateKegiatanPenutup(),
    },
    asesmen: {
      awal: generateAsesmenAwal(),
      proses: generateAsesmenProses(),
      akhir: generateAsesmenAkhir(),
    },
  };

  return generatedRPP;
}

// Helper functions
function getJenjangLabel(value: string): string {
  const map: Record<string, string> = {
    sd_mi: 'SD/MI',
    smp_mts: 'SMP/MTs',
    sma: 'SMA',
  };
  return map[value] || value;
}

function getMataPelajaranLabel(value: string): string {
  const map: Record<string, string> = {
    matematika: 'Matematika',
    ipa: 'IPA',
    ips: 'IPS',
    pai: 'PAI',
    pjok: 'PJOK',
    sb: 'Seni Budaya',
    bahasa_indonesia: 'Bahasa Indonesia',
    bahasa_inggris: 'Bahasa Inggris',
    informatika: 'Informatika',
    pkn: 'PKn',
    geografi: 'Geografi',
    sejarah: 'Sejarah',
    ekonomi: 'Ekonomi',
    sosiologi: 'Sosiologi',
    kimia: 'Kimia',
    biologi: 'Biologi',
    fisika: 'Fisika',
  };
  return map[value] || value;
}

function getAlokasiWaktu(jenjang: string): string {
  const map: Record<string, string> = {
    sd_mi: '2 x 30 menit',
    smp_mts: '2 x 40 menit',
    sma: '2 x 45 menit',
  };
  return map[jenjang] || '2 x 40 menit';
}

// Content generation functions
function generatePengetahuanAwal(_mataPelajaran: string, materi: string, jenjang: string): string {
  return `Murid pada jenjang ${jenjang} telah memiliki pengetahuan dasar tentang konsep-konsep prasyarat yang berkaitan dengan ${materi}. Sebelum mempelajari materi ini, murid perlu menguasai kemampuan dasar dari materi sebelumnya yang saling berkaitan. Beberapa murid mungkin memiliki pemahaman yang beragam tentang konsep ini, sehingga diperlukan apersepsi untuk mengidentifikasi tingkat pemahaman awal murid.`;
}

function generateMinat(mataPelajaran: string, jenjang: string): string {
  return `Minat belajar murid pada mata pelajaran ${mataPelajaran} bervariasi. Secara umum, murid pada jenjang ${jenjang} menunjukkan antusiasme yang tinggi terhadap materi yang berkaitan dengan kehidupan sehari-hari dan dapat dipraktikkan secara langsung. Murid cenderung lebih tertarik pada pembelajaran yang melibatkan aktivitas hands-on, diskusi kelompok, dan penggunaan media pembelajaran yang variatif.`;
}

function generateLatarBelakang(_jenjang: string): string {
  return `Murid berasal dari latar belakang keluarga yang beragam dengan situasi sosial-ekonomi yang berbeda-beda. Lingkungan sekitar sekolah memberikan pengalaman belajar yang beragam bagi murid. Beberapa murid memiliki akses terhadap teknologi dan sumber belajar tambahan di rumah, sementara yang lain lebih mengandalkan pembelajaran di sekolah. Keragaman ini perlu diakomodasi dalam desain pembelajaran.`;
}

function generateKebutuhanBelajar(_mataPelajaran: string, materi: string): string {
  return `Untuk memahami materi ${materi} secara mendalam, murid membutuhkan: (1) Penjelasan konsep yang sistematis dan berurutan, (2) Contoh-contoh konkret yang dekat dengan kehidupan sehari-hari, (3) Kesempatan untuk berlatih dan mengaplikasikan konsep, (4) Umpan balik yang konstruktif terhadap hasil belajar, (5) Bimbingan yang individual sesuai dengan kecepatan belajar masing-masing.`;
}

function generatePengetahuanKonseptual(materi: string, subMateri: string): string {
  return `Materi ${materi} memuat konsep-konsep fundamental yang saling terkait. Sub materi ${subMateri} membangun pemahaman konseptual yang kuat melalui pengenalan definisi, karakteristik, dan hubungan antar konsep. Pengetahuan konseptual ini menjadi fondasi untuk memahami materi lebih lanjut dan mengaplikasikannya dalam berbagai konteks.`;
}

function generatePengetahuanProsedural(_materi: string, mataPelajaran: string): string {
  return `Materi ini melibatkan serangkaian langkah-langkah prosedural yang harus dikuasai murid. Prosedur meliputi: identifikasi masalah, analisis situasi, penerapan konsep, dan evaluasi hasil. Penguasaan prosedur ini memungkinkan murid untuk menyelesaikan tugas-tugas dan masalah-masalah terkait ${mataPelajaran} secara sistematis dan efisien.`;
}

function generatePengetahuanNilai(_mataPelajaran: string, materi: string): string {
  return `Melalui pembelajaran ${materi}, murid mengembangkan nilai-nilai ketelitian, kejujuran, kerjasama, dan tanggung jawab. Materi ini juga menumbuhkan sikap ilmiah, kritis, dan kreatif dalam memandang fenomena. Nilai-nilai karakter seperti kesabaran, ketekunan, dan rasa ingin tahu juga dikembangkan selama proses pembelajaran.`;
}

function generateRelevansi(materi: string, jenjang: string): string {
  return `Materi ${materi} sangat relevan dengan kehidupan sehari-hari murid jenjang ${jenjang}. Konsep-konsep yang dipelajari dapat ditemukan dalam berbagai situasi nyata di lingkungan sekitar murid. Pembelajaran ini membantu murid memahami dan menginterpretasi fenomena yang terjadi dalam kehidupan mereka, serta mengembangkan keterampilan yang bermanfaat untuk masa depan.`;
}

function generateTingkatKesulitan(materi: string, jenjang: string): string {
  return `Materi ${materi} memiliki tingkat kesulitan sedang untuk jenjang ${jenjang}. Tantangan utama terletak pada pemahaman konsep abstrak dan penerapannya dalam konteks yang beragam. Strategi penanganan meliputi: penggunaan media pembelajaran konkret, pemberian contoh yang beragam, latihan bertahap dari sederhana ke kompleks, dan bimbingan yang intensif bagi murid yang memerlukan.`;
}

function generateStrukturMateri(_materi: string, subMateri: string): string {
  return `Struktur pembelajaran dirancang dari konkret ke abstrak: (1) Pengenalan konsep melalui contoh nyata, (2) Pembahasan teori dan definisi, (3) Demonstrasi atau simulasi, (4) Praktik dan latihan, (5) Aplikasi dalam konteks baru. Sub materi ${subMateri} disusun secara hierarkis dengan setiap bagian membangun pemahaman sebelumnya.`;
}

function generateDimensiProfilLulusan(mataPelajaran: string, _tujuanPembelajaran: string): { dimensi: string[]; penjelasan: string } {
  const dimensi = ['penalaran_kritis', 'kreativitas', 'kolaborasi'];
  
  return {
    dimensi,
    penjelasan: `Dimensi Penalaran Kritis dipilih karena materi ${mataPelajaran} menuntut murid untuk menganalisis, mengevaluasi, dan menyimpulkan informasi secara logis. Dimensi Kreativitas dikembangkan melalui tugas-tugas yang mendorong murid menghasilkan ide-ide baru dan solusi inovatif. Dimensi Kolaborasi ditekankan karena pembelajaran melibatkan kerja sama dalam kelompok untuk menyelesaikan masalah dan proyek. Ketiga dimensi ini selaras dengan tujuan pembelajaran yang mengembangkan kemampuan berpikir tingkat tinggi dan keterampilan sosial murid.`,
  };
}

function generateLintasDisiplin(mataPelajaran: string): string {
  const lintasMap: Record<string, string> = {
    'Matematika': 'IPA, Informatika, dan Ekonomi',
    'IPA': 'Matematika, IPS, dan Bahasa Indonesia',
    'IPS': 'Bahasa Indonesia, Matematika, dan PAI',
    'PAI': 'Bahasa Indonesia, IPS, dan Seni Budaya',
    'PJOK': 'IPA, Bahasa Indonesia, dan PAI',
    'Seni Budaya': 'Bahasa Indonesia, IPS, dan PAI',
    'Bahasa Indonesia': 'IPS, PAI, dan Semua Mata Pelajaran',
    'Bahasa Inggris': 'Bahasa Indonesia, IPS, dan Semua Mata Pelajaran',
    'Informatika': 'Matematika, IPA, dan Bahasa Indonesia',
    'PKn': 'Bahasa Indonesia, IPS, dan PAI',
    'Geografi': 'Biologi, Kimia, dan Matematika',
    'Sejarah': 'Bahasa Indonesia, IPS, dan PAI',
    'Ekonomi': 'Matematika, IPS, dan Geografi',
    'Sosiologi': 'Bahasa Indonesia, IPS, dan PAI',
    'Kimia': 'Matematika, Fisika, dan Biologi',
    'Biologi': 'Kimia, Fisika, dan Matematika',
    'Fisika': 'Matematika, Kimia, dan Biologi',
  };
  
  return `Mata pelajaran ${mataPelajaran} dapat diintegrasikan dengan: ${lintasMap[mataPelajaran] || 'Mata pelajaran terkait lainnya'}. Integrasi ini memungkinkan murid melihat keterkaitan antar disiplin ilmu dan mengembangkan pemahaman holistik tentang konsep yang dipelajari.`;
}

function generatePraktikPedagogis(_mataPelajaran: string, materi: string): { model: string; sintak: string[] } {
  return {
    model: 'Pembelajaran Berbasis Masalah (Problem-Based Learning)',
    sintak: [
      '1. Orientasi masalah: Pendidik menyajikan masalah nyata yang berkaitan dengan ' + materi,
      '2. Mengorganisasi murid untuk belajar: Murid dibagi dalam kelompok kecil untuk menyelidiki masalah',
      '3. Membimbing penyelidikan individual dan kelompok: Pendidik memberikan scaffolding dan sumber belajar',
      '4. Mengembangkan dan menyajikan hasil karya: Kelompok menyusun solusi dan mempresentasikannya',
      '5. Menganalisis dan mengevaluasi proses pemecahan masalah: Refleksi bersama tentang proses dan hasil pembelajaran',
    ],
  };
}

function generateKemitraan(): string {
  return `Pendidik berperan sebagai fasilitator dan mediator pembelajaran, menyediakan sumber belajar, memberikan scaffolding, dan memberikan umpan balik konstruktif. Murid menjadi pembelajar aktif yang bertanggung jawab atas proses dan hasil belajarnya, bekerja secara mandiri dan kolaboratif. Orang tua dan masyarakat dapat terlibat sebagai sumber belajar, narasumber, atau mitra dalam kegiatan pembelajaran yang terkait dengan konteks lokal.`;
}

function generateBudayaBelajar(): string {
  return `Iklim belajar yang aman, nyaman, dan saling memuliakan. Murid merasa bebas untuk mengemukakan pendapat, bertanya, dan mengalami kegagalan sebagai bagian dari proses belajar. Pendidik menghargai keberagaman cara berpikir dan belajar murid. Tercipta suasana kolaboratif di mana murid saling membantu dan belajar dari satu sama lain.`;
}

function generateRuangFisik(): string {
  return `Pengaturan ruang kelas yang fleksibel memungkinkan berbagai aktivitas pembelajaran. Meja dan kursi dapat disusun untuk kegiatan individual, berpasangan, atau kelompok. Tersedia sudut baca, area presentasi, dan ruang untuk kegiatan praktik. Papan tulis, proyektor, dan media pembelajaran lainnya tersedia dan mudah diakses.`;
}

function generateRuangVirtual(): string {
  return `Platform daring seperti Google Classroom, Zoom, atau Microsoft Teams dapat digunakan untuk pembelajaran jarak jauh atau blended learning. Sumber belajar digital seperti video pembelajaran, simulasi interaktif, dan materi online dapat diakses murid. Grup diskusi online memfasilitasi komunikasi dan kolaborasi di luar jam sekolah.`;
}

function generateKegiatanAwal(_mataPelajaran: string, materi: string): string[] {
  return [
    'Pendidik membuka dengan salam, doa, dan menyapa murid secara personal untuk membangun kedekatan',
    'Apersepsi: Pendidik mengaitkan materi ' + materi + ' dengan pengetahuan awal murid melalui pertanyaan pemantik',
    'Pendidik menyampaikan tujuan pembelajaran dan manfaat mempelajari materi ini dalam kehidupan',
    'Pendidik menjelaskan gambaran umum kegiatan pembelajaran yang akan dilakukan hari ini',
    'Pendidik membentuk kelompok belajar (jika diperlukan) dan menyampaikan aturan main',
    'Pendidik menyajikan masalah kontekstual yang berkaitan dengan ' + materi + ' untuk memicu rasa ingin tahu murid',
  ];
}

function generateKegiatanMemahami(materi: string, subMateri: string, _mataPelajaran: string): string[] {
  return [
    'Murid terlibat aktif mengkonstruksi pengetahuan melalui kegiatan eksplorasi dan investigasi',
    'Murid mengumpulkan informasi dari berbagai sumber: buku, internet, narasumber, atau pengamatan langsung',
    'Murid menganalisis konsep ' + subMateri + ' dari berbagai konteks dan perspektif',
    'Murid berdiskusi dalam kelompok untuk bertukar pikiran dan memperdalam pemahaman',
    'Pendidik memberikan scaffolding melalui pertanyaan-pertanyaan yang memancing berpikir kritis',
    'Murid menyusun peta konsep atau diagram untuk mengorganisasi informasi yang dikumpulkan',
    'Murid mengidentifikasi hubungan antar konsep dalam materi ' + materi,
  ];
}

function generateKegiatanMengaplikasi(materi: string, _mataPelajaran: string): string[] {
  return [
    'Murid mengaplikasikan pemahaman tentang ' + materi + ' dalam konteks kehidupan nyata',
    'Murid menyelesaikan masalah autentik yang berkaitan dengan lingkungan sekitar',
    'Murid melakukan praktik, proyek, atau membuat produk yang menunjukkan penguasaan konsep',
    'Murid menunjukkan aktivitas nyata (hidup, kehidupan, penghidupan) yang terkait dengan materi',
    'Murid bekerja dalam kelompok untuk menyelesaikan tugas aplikasi yang kompleks',
    'Pendidik memberikan bimbingan dan dukungan sesuai kebutuhan masing-masing murid',
    'Murid mempresentasikan hasil aplikasi dan mendapatkan umpan balik dari teman dan pendidik',
  ];
}

function generateKegiatanMerefleksi(): string[] {
  return [
    'Murid mengevaluasi proses dan hasil tindakan/praktik yang telah dilakukan',
    'Murid memaknai pengalaman belajar dan keterkaitannya dengan kehidupan',
    'Murid menentukan tindak lanjut untuk perbaikan di masa depan',
    'Murid mengelola proses belajar secara mandiri dan bertanggung jawab',
    'Murid meneruskan strategi yang berhasil dan memperbaiki yang belum berhasil',
    'Murid meningkatkan motivasi dan kepercayaan diri melalui pengakuan atas kemajuan yang dicapai',
    'Pendidik memfasilitasi refleksi melalui pertanyaan-pertanyaan reflektif',
  ];
}

function generateKegiatanPenutup(): string[] {
  return [
    'Pendidik memberikan umpan balik konstruktif atas pengalaman belajar murid',
    'Bersama murid, pendidik menyimpulkan pembelajaran yang telah dilakukan',
    'Pendidik memandu refleksi proses dan hasil pembelajaran',
    'Murid terlibat dalam perencanaan pembelajaran selanjutnya',
    'Pendidik memberikan arahan untuk belajar mandiri di rumah',
    'Pendidik menutup dengan doa dan salam',
  ];
}

function generateAsesmenAwal(): string {
  return `Teknik: Tes diagnostik (kuis singkat, pertanyaan lisan, atau lembar kerja)
Instrumen: Soal-soal prasyarat, angket minat dan gaya belajar
Tujuan: Mengukur kesiapan dan pengetahuan awal murid sebelum mempelajari materi baru`;
}

function generateAsesmenProses(): string {
  return `Teknik: Observasi, penugasan, diskusi, dan unjuk kerja
Instrumen: Lembar observasi sikap, rubrik penilaian tugas, catatan anekdot
Tujuan: Memantau proses dan perkembangan belajar murid secara berkelanjutan
Rubrik: Penilaian sikap (aktivitas, kerjasama, tanggung jawab) dan keterampilan proses`;
}

function generateAsesmenAkhir(): string {
  return `Teknik: Tes sumatif dan unjuk kerja produk/proyek
Instrumen: Soal evaluasi, rubrik penilaian produk/proyek
Tujuan: Mengukur pencapaian kompetensi setelah pembelajaran selesai
Kriteria Ketuntasan: Minimal 75% murid mencapai KKM (Kriteria Ketuntasan Minimal)`;
}