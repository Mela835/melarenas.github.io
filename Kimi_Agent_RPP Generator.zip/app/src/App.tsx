import { useState, useCallback } from 'react';
import { RPPForm } from '@/components/RPPForm';
import { RPPResult } from '@/components/RPPResult';
import { Toaster } from '@/components/ui/toaster';
import type { RPPFormData, GeneratedRPP } from '@/types/rpp';
import { generateRPP } from '@/services/rppGenerator';
import { BookOpen, GraduationCap, Sparkles } from 'lucide-react';

function App() {
  const [generatedRPP, setGeneratedRPP] = useState<GeneratedRPP | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = useCallback(async (formData: RPPFormData) => {
    setIsLoading(true);
    try {
      const rpp = await generateRPP(formData);
      setGeneratedRPP(rpp);
      // Scroll to result on mobile
      setTimeout(() => {
        const resultElement = document.getElementById('rpp-result');
        if (resultElement && window.innerWidth < 1024) {
          resultElement.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } catch (error) {
      console.error('Error generating RPP:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleReset = useCallback(() => {
    setGeneratedRPP(null);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-2.5 rounded-xl shadow-lg">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-blue-900 to-indigo-800 bg-clip-text text-transparent">
                  Generator RPP
                </h1>
                <p className="text-xs sm:text-sm text-slate-500 flex items-center gap-1">
                  <BookOpen className="w-3 h-3" />
                  Pembelajaran Mendalam
                  <Sparkles className="w-3 h-3 text-yellow-500 ml-1" />
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">Design by</p>
              <p className="text-sm font-semibold text-blue-700">Mela Renas</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form Section */}
          <div className="order-1">
            <RPPForm 
              onSubmit={handleSubmit} 
              onReset={handleReset}
              isLoading={isLoading} 
            />
          </div>

          {/* Result Section */}
          <div id="rpp-result" className="order-2">
            <RPPResult rpp={generatedRPP} />
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl p-6 shadow-md border border-slate-100 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Format Lengkap</h3>
            <p className="text-sm text-slate-600">
              RPP lengkap dengan identifikasi murid, desain pembelajaran, pengalaman belajar, dan asesmen.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md border border-slate-100 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <Sparkles className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Generate Otomatis</h3>
            <p className="text-sm text-slate-600">
              Sistem generate otomatis berdasarkan input Anda dengan alokasi waktu yang disesuaikan.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md border border-slate-100 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <GraduationCap className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Pembelajaran Mendalam</h3>
            <p className="text-sm text-slate-600">
              Dirancang sesuai prinsip pembelajaran mendalam dengan pendekatan student-centered.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-slate-500">
              © 2024 Generator RPP Pembelajaran Mendalam
            </p>
            <p className="text-sm text-slate-400">
              Design by <span className="text-blue-600 font-medium">Mela Renas</span>
            </p>
          </div>
        </div>
      </footer>

      <Toaster />
    </div>
  );
}

export default App;
